# Project-4
## County Fair - exhaustive and dynamic programming
In this project, we are given 3 problems. In each problem, we are to fill in the skeleton code to solve the problems such as the dynamic and the exhaustive algorithms to find the most worth rides to go on at the county fair. First, we create pseudo code to solve the problems. Next, implement the pseudo code into actual code and start testing. After, analyze your psuedo code mathematically on the psuedo codes efficiency class. Then, we time each algorithm method to gather empirical data, plot the results on a scatter plot, and then compare results to prove our hypothesis which is:
1. Exhaustive search algorithms are feasible to implement, and produce correct outputs.
2. Algorithms with exponential running times are extremely slow, probably too slow to be of practical use.

Group members:

Clay Golan clayg@csu.fullerton.edu

John Tarroza tarrozajohn@csu.fullerton.edu

